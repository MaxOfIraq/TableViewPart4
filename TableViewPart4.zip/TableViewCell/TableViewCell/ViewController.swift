//
//  ViewController.swift
//  TableViewCell
//
//  Created by Ahmed Salah on 04/01/2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {


    @IBOutlet weak var tableview: UITableView!
    
    let refresh = UIRefreshControl()
    var serchingName = [String()]
    var serching = false
    
    let NameVC = ["Ahmed", "Ali","Max"]
    
    let ImageVC = [UIImage(named: "insta2"), UIImage(named: "youtube"), UIImage(named: "instagram")]
    
    let urls = ["https://youtube.com", "https://instgram.com", "https://facebook.com"]
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.delegate = self
        tableview.dataSource = self
        
        refresh.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        refresh.addTarget(self, action: #selector(getData), for: .valueChanged)
        tableview.addSubview(refresh)
    }
    
    @objc func getData(){
        refresh.endRefreshing()
        tableview.reloadData()
    }

    
    
    
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return NameVC.count
    }
    
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as! TableViewCell
        cell.NameVC.text = self.NameVC[indexPath.row]
        cell.ImageVC.image = self.ImageVC[indexPath.row]
        
        return cell
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let url = URL(string: urls[indexPath.row]){
            UIApplication.shared.open(url)
        }
    }
    
    
    

}

